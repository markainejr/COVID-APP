import React from "react";
import history from "../../history";

function Navbar() {
  return (
    <nav class='navbar bg-light'>
      <div class='container-fluid'>
        <a class='navbar-brand'>Covid-19 Vaccination Center</a>
        <form class='d-flex' role='search'>
          <button
            class='btn btn-outline-info'
            type='button'
            onClick={() => {
              history.push("/");
              window.location.reload();
            }}
          >
            Logout
          </button>
        </form>
      </div>
    </nav>
  );
}

export default Navbar;
