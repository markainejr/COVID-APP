import React, { useEffect } from "react";
import { Route, Link, Routes, useLocation, Switch } from "react-router-dom";
import LoginForm from "./pages/login";
import HomePage from "./pages/vaccine-registration-form";
import history from "./history";
function App() {
  // useEffect(() => {
  //   return () => {
  //     localStorage.();
  //   };
  // });
  return (
    <Routes>
      <Route path='/VaccinationRegistration' element={<HomePage />} />
      <Route exact path='/' element={<LoginForm />} />
      <Route path='*' element={<LoginForm />} />
    </Routes>
  );
}

export default App;
