import React from "react";
import VaccinationForm from "./VaccinationForm";
import Navbar from "../../components/navbar";
import ListView from "./List";
import covid19 from "../../c-19.png";
function HomePage() {
  return (
    <div style={{ backgroundColor: "antiquewhite", height: "100vh", backgroundImage: `url(${covid19})` }}>
      <Navbar />
      <VaccinationForm />
    </div>
  );
}

export default HomePage;
