import React, { useEffect, useState } from "react";

function ListView({ registeredPersons, deletePerson, updatePerson }) {
  const [persons, setPersons] = useState([]);
  useEffect(() => {
    setPersons(registeredPersons);
  });
  return (
    <ul class='list-group'>
      {/*<li class='list-group-item d-flex justify-content-between align-items-center'>
        A list item
        <span class='badge bg-primary rounded-pill'>14</span>
      </li>
      <li class='list-group-item d-flex justify-content-between align-items-center'>
        A second list item
        <span class='badge bg-primary rounded-pill'>2</span>
      </li>
      <li class='list-group-item d-flex justify-content-between align-items-center'>
        A third list item
        <span class='badge bg-primary rounded-pill'>1</span>
  </li>*/}
      {persons?.map((item, index) => {
        return (
          <li
            class='list-group-item d-flex justify-content-between align-items-center'
            key={index}
            style={{ backgroundColor: "#effbff" }}
          >
            name: {item.full_name}
            <br />
            nin: {item.nin}
            <br />
            email: {item.email}
            <br />
            contact: {item.phone}
            <br />
            vaccine type: {item.vacType}
            <br />
            dob: {item.dob}
            <br />
            date of vaccination: {item.dateOfVaccination}
            <br />
            gender: {item.gender}
            <br />
            district: {item.district}
            <span
              class='badge bg-secondary rounded-pill'
              style={{ padding: 24, margin: 12, cursor: "pointer", color: "#ffffff" }}
              onClick={() => {
                updatePerson(item);
              }}
            >
              Update
            </span>{" "}
            <span
              class='badge bg-warning rounded-pill'
              style={{ padding: 24, margin: 12, cursor: "pointer", color: "#ffffff" }}
              onClick={() => {
                deletePerson(item.id);
              }}
            >
              x
            </span>
          </li>
        );
      })}
    </ul>
  );
}

export default ListView;
