import React, { Component } from "react";
import FormValidator from "../../components/form-validator";
import ListView from "./List";
class VaccinationForm extends Component {
  constructor() {
    super();
    this.state = {
      full_name: "",
      phone: "",
      dob: "",
      gender: "",
      dateOfVaccination: "",
      nin: "",
      district: "",
      vacType: "",
      RegisteredList: [],
      submitText: "Register",
      email: "",
      editFlag: false,
      person: null,
    };
    this.submitted = false;
  }

  componentDidMount() {
    if (localStorage.getItem("registeredList") != null || localStorage.getItem("registeredList") != undefined) {
      this.setState({ RegisteredList: JSON.parse(localStorage.getItem("registeredList")) });
    }
    if (localStorage.getItem("idCounter") == null) {
      localStorage.setItem("idCounter", 1);
    }
  }
  componentDidUpdate(prevProps, prevState) {}

  deletePerson = id => {
    let newArr = this.state.RegisteredList.filter(item => item.id != id);
    localStorage.setItem("registeredList", JSON.stringify(newArr));
    this.setState({ RegisteredList: JSON.parse(localStorage.getItem("registeredList")) });
  };

  updatePerson = person => {
    this.setState({
      full_name: person.full_name,
      phone: person.phone,
      nin: person.nin,
      email: person.email,
      dob: person.dob,
      gender: person.gender,
      vacType: person.vacType,
      dateOfVaccination: person.dateOfVaccination,
      district: person.district,
    });
    this.setState({ submitText: "Update", editFlag: true, person });
  };

  setEditFlag = value => {
    this.setState({ submitText: value });
  };

  resetState = () => {
    this.setState({
      full_name: "",
      phone: "",
      dob: "",
      gender: "",
      email: "",
      dateOfVaccination: "",
      nin: "",
      district: "",
      vacType: "",
      submitText: "Register",
      editFlag: false,
      person: null,
    });
  };

  render() {
    let validation = this.submitted ? this.validator.validate(this.state) : this.state.validation;
    return (
      <div className='container px-4'>
        <div className='row gx-5'>
          <div
            className='col-6'
            style={{
              marginTop: 48,
              border: "1px solid gray",
              borderRadius: "12px",
              padding: "12px",
              backgroundColor: "#ffc107",
              opacity: "88%",
            }}
          >
            <div
              style={{
                fontSize: 24,
                fontWeight: "bold",
                margin: "12px",
                textAlign: "center",
                backgroundColor: "#0096b3",
                borderRadius: "12px",
                color: "white",
              }}
            >
              Vaccination Registeration
            </div>
            <form>
              <div class='form-group'>
                <label for='nin-number'>NIN</label>
                <input
                  type='text'
                  maxLength={30}
                  class='form-control'
                  id='nin-number'
                  value={this.state.nin}
                  onChange={e => {
                    this.setState({ nin: e.currentTarget.value });
                  }}
                />
              </div>
              <div class='form-group'>
                <label for='email'>Email</label>
                <input
                  type='email'
                  maxLength={30}
                  class='form-control'
                  id='email'
                  value={this.state.email}
                  onChange={e => {
                    this.setState({ email: e.currentTarget.value });
                  }}
                />
              </div>
              <div class='form-group'>
                <label for='nameOfCitizen'>Citizen Name</label>
                <input
                  type='text'
                  maxLength={70}
                  class='form-control'
                  id='nameOfCitizen'
                  value={this.state.full_name}
                  onChange={e => {
                    this.setState({ full_name: e.currentTarget.value });
                  }}
                />
              </div>
              <div className='row'>
                <div class='form-group col-6'>
                  <label for='contact'>Phone/Contact</label>
                  <input
                    type='text'
                    maxLength={70}
                    class='form-control'
                    id='contact'
                    value={this.state.phone}
                    onChange={e => {
                      this.setState({ phone: e.currentTarget.value });
                    }}
                  />
                </div>
                <div class='form-group col-6'>
                  <select
                    class='form-select'
                    aria-label='Default select example'
                    onChange={e => {
                      this.setState({ vacType: e.currentTarget.value });
                    }}
                    style={{ marginTop: "12%", width: "100%" }}
                    value={this.state.vacType}
                  >
                    <option selected>Please select vaccine type</option>
                    <option value='Pfizer'>Pfizer</option>
                    <option value='AstraZeneca'>AstraZeneca</option>
                    <option value='Moderna'>Moderna</option>
                    <option value='Novavax'>Novavax</option>
                    <option value='Johnson & Johnson'>Johnson & Johnson</option>                
                  </select>
                </div>
              </div>
              <div className='row'>
                <div class='form-group col-6'>
                  <label for='vaccination-date'>Date of Vaccination</label>
                  <input
                    type='date'
                    onChange={e => {
                      this.setState({ dateOfVaccination: e.currentTarget.value });
                    }}
                    value={this.state.dateOfVaccination}
                    maxLength={70}
                    class='form-control'
                    id='vaccination-date'
                  />
                </div>
                <div class='form-group col-6'>
                  <label for='dob'>Date of Birth</label>
                  <input
                    type='date'
                    onChange={e => {
                      this.setState({ dob: e.currentTarget.value });
                    }}
                    maxLength={70}
                    class='form-control'
                    id='dob'
                    value={this.state.dob}
                  />
                </div>
              </div>
              <div className='row'>
                <div class='form-group col-6'>
                  <select
                    class='form-select'
                    aria-label='Default select example'
                    style={{ marginTop: "12%", width: "100%" }}
                    id='gender'
                    onChange={e => {
                      this.setState({ gender: e.currentTarget.value });
                    }}
                    value={this.state.gender}
                  >
                    <option selected>Please select gender</option>
                    <option value='male'>Male</option>
                    <option value='female'>Female</option>
                    <option value='transgender'>Transgender</option>
                  </select>
                </div>
                <div class='form-group col-6'>
                  <select
                    class='form-select'
                    aria-label='Default select example'
                    onChange={e => {
                      this.setState({ district: e.currentTarget.value });
                    }}
                    style={{ marginTop: "12%", width: "100%" }}
                    value={this.state.district}
                  >
                    <option selected>Please select district</option>
                    <option value='Buikwe'>Buikwe</option>
                    <option value='Butambala'>Butambala</option>
                    <option value='Jinja'>Jinja</option>
                    <option value='Kampala'>Kampala</option>
                    <option value='Kayunga'>Kayunga</option>
                    <option value='Luwero'>Luwero</option>
                    <option value='Luwero'>Mityana</option>
                    <option value='Mpigi'>Mpigi</option>
                    <option value='Mukono'>Mukono</option>
                    <option value='Wakiso'>Wakiso</option>
                    <option value='Others'>Others</option>
                     </select>
                </div>
              </div>

              <button
                type='button'
                class='btn btn-primary'
                onClick={() => {
                  const { full_name, phone, dob, gender, dateOfVaccination, nin, district, vacType, email } = this.state;
                  if (
                    full_name == "" ||
                    phone == "" ||
                    dob == "" ||
                    gender == "" ||
                    dateOfVaccination == "" ||
                    nin == "" ||
                    district == "" ||
                    vacType == "" ||
                    email == ""
                  ) {
                    window.alert("fill all fields first");
                  } else {
                    console.log({ state: this.state });

                    if (!this.state.editFlag) {
                      let newEntry = {
                        id: parseInt(localStorage.getItem("idCounter")) + 1,
                        full_name,
                        phone,
                        dob,
                        gender,
                        dateOfVaccination,
                        nin,
                        district,
                        vacType,
                        email,
                      };
                      let list =
                        JSON.parse(localStorage.getItem("registeredList")) == null
                          ? []
                          : JSON.parse(localStorage.getItem("registeredList"));

                      let checkNin = this.state.RegisteredList.filter(item => item.nin == nin);
                      console.log({ checkNin });
                      if (checkNin.length < 1) {
                        list.push(newEntry);
                        localStorage.setItem("registeredList", JSON.stringify(list));
                        this.setState({ RegisteredList: list });
                        localStorage.setItem("idCounter", parseInt(localStorage.getItem("idCounter")) + 1);
                      } else {
                        window.alert("This NIN is already registered");
                      }
                    } else {
                      let newEntry = {
                        id: this.state.person.id,
                        full_name,
                        phone,
                        dob,
                        gender,
                        dateOfVaccination,
                        nin,
                        district,
                        vacType,
                        email,
                      };
                      let list =
                        JSON.parse(localStorage.getItem("registeredList")) == null
                          ? []
                          : JSON.parse(localStorage.getItem("registeredList"));
                      let index = list.findIndex(item => item.id == this.state.person.id);
                      list[index] = newEntry;
                      localStorage.setItem("registeredList", JSON.stringify(list));
                      this.setState({ RegisteredList: list });
                    }
                    this.setState({ editFlag: false, person: null });
                  }
                  this.setEditFlag("Register");
                  this.resetState();
                }}
              >
                {this.state.submitText}
              </button>
            </form>
          </div>
          <div className='col-6' style={{ marginTop: 48, backgroundColor: "#effbff", borderRadius: "12px", opacity: "95%" }}>
            <h4 style={{ padding: 12 }}>Registered List</h4>
            <ListView
              registeredPersons={this.state.RegisteredList}
              deletePerson={this.deletePerson}
              updatePerson={this.updatePerson}
            />
          </div>
        </div>
      </div>
    );
  }
}
export default VaccinationForm;
