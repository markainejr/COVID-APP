tools needed to run: node, npm, react
start script: npm start
node_modules_installation script : npm install

authenticated users : 
1- username = user1, password = pass1
2- username = user2, password = pass2